
#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &> /dev/null && pwd)
ROOT_DIR=$(cd "$SCRIPT_DIR/.." && pwd)
set -a
source "$ROOT_DIR/azure/.env"
set +a

RG=${AZ_RESOURCE_GROUP:-amawe-rtt-rg}
PREFIX=${AZ_PREFIX:-amawe}
REPO=${ACR_REPO:-backend}

ACR_NAME=$(az acr list -g "$RG" --query "[0].name" -o tsv)
if [ -z "$ACR_NAME" ]; then
  echo "ACR not found in resource group $RG"; exit 1
fi

az acr login -n "$ACR_NAME"

docker build -t $ACR_NAME.azurecr.io/$PREFIX/$REPO:latest "$ROOT_DIR/src/backend"

docker push  $ACR_NAME.azurecr.io/$PREFIX/$REPO:latest

az containerapp update -g "$RG" -n ${PREFIX}-rtt-backend   --image $ACR_NAME.azurecr.io/$PREFIX/$REPO:latest
