
#!/usr/bin/env bash
set -euo pipefail

# Load .env
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &> /dev/null && pwd)
ROOT_DIR=$(cd "$SCRIPT_DIR/.." && pwd)
set -a
source "$ROOT_DIR/azure/.env"
set +a

RG=${AZ_RESOURCE_GROUP:-amawe-rtt-rg}
WE=${AZ_LOCATION_WE:-westeurope}
SC=${AOAI_LOCATION_SC:-swedencentral}
PREFIX=${AZ_PREFIX:-amawe}

az group create -n "$RG" -l "$WE"

az deployment group create   -g "$RG"   -f "$SCRIPT_DIR/main.bicep"   -p location=$WE aoaiLocation=$SC namePrefix=$PREFIX aoaiApiKey=$AOAI_API_KEY

