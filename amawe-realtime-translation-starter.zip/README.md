
# AMAWE Realtime Translation (.NET + MAUI + Azure Bicep)

Dieses Starterpaket basiert auf:
- Backend: ASP.NET Core 8 (WebSockets) – Orchestrator/Bridge zu Azure OpenAI **GPT‑4o Realtime**
- Frontend: .NET MAUI (Android/iOS/Windows) – Push‑to‑Talk, Chunks an WS
- Infrastruktur: Azure Bicep (Azure Container Apps, ACR, App Insights, Azure OpenAI, Azure Communication Services **Rooms**)
- Dev Container: VS Code `.devcontainer` mit .NET SDK, Azure CLI, Bicep
- On‑Prem/Offline‑Demo: `DEMO_MODE=true` -> Backend echo’t Audio/Text ohne Azure

## Schnellstart (lokal)

```bash
# 1) Dev-Container öffnen (VS Code) oder .NET 8 lokal nutzen
# 2) Backend lokal starten
cd src/backend
cp ../../azure/.env.example ../../azure/.env
# optional: DEMO_MODE=true für reine Offline-Demo
export $(grep -v '^#' ../../azure/.env | xargs)
dotnet run

# 3) MAUI-App öffnen/bauen (Android/iOS/Windows je nach Host)
```

> Für sehr geringe Latenz (WebRTC) und Regionen/Modelle siehe Azure OpenAI Realtime Doku (Preview). GPT‑4o Realtime ist u. a. in *Sweden Central* verfügbar; Server‑zu‑Server wird über WebSockets beschrieben. 

## Azure Deployment (Bicep)

1. `azure/.env` ausfüllen (siehe `azure/.env.example`):
2. Infrastruktur deployen:

```bash
cd infra
./deploy.sh  # lädt .env und führt az deployment group create aus
```

3. Backend-Image bauen & in ACR pushen, Container App updaten:

```bash
./push-image.sh
```

## Verzeichnisstruktur
```
.
├─ azure/
│  ├─ .env.example          # Parameter für Deployment & lokale Variablen
├─ infra/
│  ├─ main.bicep            # AOAI (Sweden Central), ACA, ACR, ACS, Insights
│  ├─ deploy.sh             # liest azure/.env und deployt
│  └─ push-image.sh         # baut/pusht Backend-Image und aktualisiert ACA
├─ src/
│  ├─ backend/              # ASP.NET Core 8 WS-Orchestrator
│  └─ maui-app/             # .NET MAUI App
└─ .devcontainer/
   ├─ devcontainer.json
   └─ Dockerfile
```

## Hinweise & Quellen
- Azure OpenAI **GPT‑4o Realtime** (Modelle/Regionen, WS/WebRTC, API-Version): siehe Microsoft Learn.  
- Azure Container Apps – .NET & WS/Ingress/Probes: siehe Microsoft Learn.  
- ACA Health-Probes vs. WebSockets: bei fehlender HTTP‑Probe können WS‑Server Fehler loggen – eigener `/health` Endpoint empfohlen.  
- Azure Communication Services **Rooms** (Konzepte/SDK/Quickstarts): siehe Doku & Samples.

