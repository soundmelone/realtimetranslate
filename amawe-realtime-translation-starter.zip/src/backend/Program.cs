
using System.Collections.Concurrent;
using System.Net.WebSockets;
using System.Text;
using Azure.Communication;
using Azure.Communication.Identity;
using Azure.Communication.Rooms;
using Azure;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// Health for ACA
app.MapGet("/health", () => Results.Ok("ok"));

var DEMO_MODE = Environment.GetEnvironmentVariable("DEMO_MODE")?.ToLowerInvariant() == "true";
var AOAI_WSS = Environment.GetEnvironmentVariable("AOAI_REALTIME_WSS");
var AOAI_KEY = Environment.GetEnvironmentVariable("AOAI_API_KEY");
var ACS_CONN = Environment.GetEnvironmentVariable("ACS_CONNECTION_STRING");

var roomMap = new ConcurrentDictionary<string,string>(); // roomId -> acsRoomId
CommunicationIdentityClient? identityClient = null;
RoomsClient? roomsClient = null;

if (!string.IsNullOrEmpty(ACS_CONN))
{
    identityClient = new CommunicationIdentityClient(ACS_CONN);
    roomsClient = new RoomsClient(ACS_CONN);
}

app.MapPost("/rooms/{roomId}/ensure", async (string roomId) =>
{
    if (DEMO_MODE || roomsClient is null)
    {
        roomMap.TryAdd(roomId, roomId); // pseudo mapping
        return Results.Ok(new { acsRoomId = roomId, demo = true });
    }

    if (roomMap.ContainsKey(roomId))
        return Results.Ok(new { acsRoomId = roomMap[roomId], reused = true });

    var validFrom = DateTimeOffset.UtcNow.AddMinutes(-5);
    var validUntil = DateTimeOffset.UtcNow.AddHours(6);
    var created = await roomsClient.CreateRoomAsync(new() {
        ValidFrom = validFrom,
        ValidUntil = validUntil,
        RoomJoinPolicy = RoomJoinPolicy.InviteOnly
    });
    roomMap[roomId] = created.Value.Id;
    return Results.Ok(new { acsRoomId = created.Value.Id });
});

app.MapPost("/rooms/{roomId}/token", async (string roomId) =>
{
    if (DEMO_MODE || identityClient is null)
    {
        return Results.Ok(new { userId = $"demo:{Guid.NewGuid()}", accessToken = "demo-token", expiresOn = DateTimeOffset.UtcNow.AddHours(1) });
    }

    var user = await identityClient.CreateUserAsync();
    var token = await identityClient.GetTokenAsync(user.Value, new[] { CommunicationTokenScope.VoIP });

    // Optional: Teilnehmer zu ACS Room hinzufügen (wenn roomMap vorhanden)
    if (roomMap.TryGetValue(roomId, out var acsRoomId))
    {
        try
        {
            await roomsClient!.AddParticipantsAsync(acsRoomId, new[] {
                new RoomParticipant(new CommunicationUserIdentifier(user.Value.Id)) { Role = ParticipantRole.Attendee }
            });
        }
        catch (RequestFailedException) { /* ignore for demo */ }
    }

    return Results.Ok(new { userId = user.Value.Id, accessToken = token.Value.Token, expiresOn = token.Value.ExpiresOn });
});

app.Map("/ws/audio/{roomId}", async (HttpContext http, string roomId) =>
{
    if (!http.WebSockets.IsWebSocketRequest)
    {
        http.Response.StatusCode = 400; return;
    }

    using var client = await http.WebSockets.AcceptWebSocketAsync();

    if (DEMO_MODE || string.IsNullOrEmpty(AOAI_WSS) || string.IsNullOrEmpty(AOAI_KEY))
    {
        // Echo-Server: empfängt Binärdaten und sendet sie zurück + Textinfo
        var buf = new byte[8192];
        while (!http.RequestAborted.IsCancellationRequested)
        {
            var res = await client.ReceiveAsync(buf, http.RequestAborted);
            if (res.MessageType == WebSocketMessageType.Close) break;
            // 1) einfache Textnotiz
            var msg = Encoding.UTF8.GetBytes("{"transcript":"DEMO: Audio empfangen"}");
            await client.SendAsync(msg, WebSocketMessageType.Text, endOfMessage: true, http.RequestAborted);
            // 2) Audio zurück
            await client.SendAsync(buf.AsMemory(0, res.Count), WebSocketMessageType.Binary, res.EndOfMessage, http.RequestAborted);
        }
        try { await client.CloseAsync(WebSocketCloseStatus.NormalClosure, "demo-closed", http.RequestAborted); } catch {}
        return;
    }

    // Produktiv: Brücke zu Azure OpenAI Realtime WS
    using var aoai = new ClientWebSocket();
    aoai.Options.SetRequestHeader("api-key", AOAI_KEY);
    await aoai.ConnectAsync(new Uri(AOAI_WSS), http.RequestAborted);

    // Client->AOAI forward
    _ = Task.Run(async () =>
    {
        var buffer = new byte[8192];
        try
        {
            while (!http.RequestAborted.IsCancellationRequested)
            {
                var res = await client.ReceiveAsync(buffer, http.RequestAborted);
                if (res.MessageType == WebSocketMessageType.Close) break;
                await aoai.SendAsync(buffer.AsMemory(0, res.Count), res.MessageType, res.EndOfMessage, http.RequestAborted);
            }
        }
        catch { }
        try { await aoai.CloseAsync(WebSocketCloseStatus.NormalClosure, "client-closed", http.RequestAborted); } catch {}
    });

    // AOAI->Client forward
    var buf2 = new byte[8192];
    while (!http.RequestAborted.IsCancellationRequested && aoai.State == WebSocketState.Open)
    {
        var res = await aoai.ReceiveAsync(buf2, http.RequestAborted);
        if (res.MessageType == WebSocketMessageType.Close) break;
        await client.SendAsync(buf2.AsMemory(0, res.Count), res.MessageType, res.EndOfMessage, http.RequestAborted);
    }

    try { await client.CloseAsync(WebSocketCloseStatus.NormalClosure, "done", http.RequestAborted); } catch {}
});

app.Run();
