
using System.Net.WebSockets;
using System.Text;
using Plugin.Maui.Audio;

namespace amawe.RttApp;

public partial class MainPage : ContentPage
{
    private readonly RttClient _client;

    public MainPage(RttClient client)
    {
        InitializeComponent();
        _client = client;
    }

    private async void OnConnect(object sender, EventArgs e)
    {
        try
        {
            var backend = new Uri(BackendEntry.Text!.TrimEnd('/'));
            var room = RoomEntry.Text!.Trim();
            await _client.ConnectAsync(backend, room, msg => MainThread.BeginInvokeOnMainThread(() =>
            {
                Transcript.Text += msg + "
";
            }));
            StatusLabel.Text = "Status: connected";
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async void OnEnsureRoom(object sender, EventArgs e)
    {
        try
        {
            var backend = new Uri(BackendEntry.Text!.TrimEnd('/'));
            var room = RoomEntry.Text!.Trim();
            using var http = new HttpClient();
            var res = await http.PostAsync(new Uri(backend, $"/rooms/{room}/ensure"), null);
            StatusLabel.Text = $"Ensure: {res.StatusCode}";
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private Task OnStartTalk(object sender, EventArgs e) => _client.StartTalkAsync();
    private Task OnStopTalk(object sender, EventArgs e)  => _client.StopTalkAsync();
}

public class RttClient
{
    private readonly IAudioManager _audio;
    private ClientWebSocket? _ws;
    private IAudioRecorder _rec = null!;
    private Action<string>? _onText;

    public RttClient(IAudioManager audio) => _audio = audio;

    public async Task ConnectAsync(Uri backend, string roomId, Action<string> onText)
    {
        _onText = onText;
        _ws = new ClientWebSocket();
        await _ws.ConnectAsync(new Uri(backend, $"/ws/audio/{roomId}"), CancellationToken.None);
        _rec = _audio.CreateRecorder();
        _ = Task.Run(ReceiveLoop); // Textnachrichten (Transkript) empfangen
    }

    private async Task ReceiveLoop()
    {
        var buf = new byte[8192];
        while (_ws?.State == WebSocketState.Open)
        {
            var res = await _ws.ReceiveAsync(buf, CancellationToken.None);
            if (res.MessageType == WebSocketMessageType.Close) break;
            if (res.MessageType == WebSocketMessageType.Text)
            {
                var txt = Encoding.UTF8.GetString(buf, 0, res.Count);
                _onText?.Invoke(txt);
            }
        }
    }

    public Task StartTalkAsync() => _rec.StartAsync();

    public async Task StopTalkAsync()
    {
        var src = await _rec.StopAsync();
        using var s = await src.GetAudioStreamAsync();
        var buf = new byte[8192]; int r;
        while ((r = await s.ReadAsync(buf, 0, buf.Length)) > 0)
        {
            await _ws!.SendAsync(buf.AsMemory(0, r), WebSocketMessageType.Binary, endOfMessage: false, CancellationToken.None);
        }
        await _ws!.SendAsync(ReadOnlyMemory<byte>.Empty, WebSocketMessageType.Binary, endOfMessage: true, CancellationToken.None);
    }
}
