
using Microsoft.Maui.Hosting;
using Plugin.Maui.Audio;

namespace amawe.RttApp;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>();

        builder.Services.AddAudio();
        builder.Services.AddSingleton<MainPage>();
        builder.Services.AddSingleton<RttClient>();
        return builder.Build();
    }
}
