
# Realtime Translation – azd Deployment

Diese Vorlage macht das Repository `azd`-fähig und deployt Frontend (Next.js, Static Web Apps) und Orchestrator (FastAPI, Azure Container Apps) samt Azure-Ressourcen mit einem Befehl.

## Voraussetzungen
- **Azure Developer CLI (azd)** installiert und angemeldet (`azd auth login`).
- **Azure CLI** (optional für erweiterte Befehle).
- **Node.js** für das Frontend-Build.
- **Python 3.11** (lokal nur nötig, wenn du das Orchestrator-Image lokal bauen willst).

## Schnellstart
```bash
# 1) Login & Basiskonfig
azd auth login
azd config set defaults.location westeurope

# 2) Secrets & Settings
azd env set-secret AOAI_API_KEY "<dein-aoai-key>"
azd env set AOAI_ENDPOINT "https://<your-aoai>.openai.azure.com/"
azd env set AOAI_DEPLOYMENT "gpt-4o-mini-realtime-preview"
azd env set-secret ACS_CONNECTION_STRING "<acs-connection-string>"

# 3) Provision + Deploy
azd up
```

> Hinweise:
> - `AOAI_*` verweisen auf dein Azure OpenAI / Azure AI Foundry Deployment des Realtime-Modells.
> - `ACS_CONNECTION_STRING` stammt aus deiner Azure Communication Services Ressource.

## Struktur
```
.
├─ azure.yaml
├─ infra/
│  ├─ main.bicep
│  └─ main.parameters.json
├─ src/
│  ├─ orchestrator/
│  │  ├─ Dockerfile
│  │  └─ requirements.txt
│  └─ web-ui/
│     ├─ next.config.js
│     └─ package.json
└─ README.md
```

## Wichtige Einstellungen
- **Frontend (Next.js)** wird statisch exportiert (`next export`) und als **Azure Static Web App** bereitgestellt.
- **Orchestrator** läuft als **Azure Container App** (Port 8000, Uvicorn). Secrets werden als Container-Umgebungsvariablen injiziert.
- **Key Vault** wird von `azd` automatisch zur Secret-Verwaltung genutzt (via `azd env set-secret`).

## Nützliche azd-Befehle
```bash
# Nur Infrastruktur provisionieren
azd provision

# Nur Code neu deployen
azd deploy

# Werte/Outputs anzeigen
azd show

# Umgebung löschen
azd down
```

## Smoke-Test
1. Prüfe die **Container App URL** (`containerAppUrl` Output) → `GET /healthz` sollte 200 liefern (falls implementiert).
2. Öffne die **Static Web App URL** und stelle sicher, dass die UI den Orchestrator erreichen kann.
3. Teste ACS-Room-Join und GPT‑4o Realtime-Flow gemäß App-UI.

Viel Erfolg!
